SELECT * FROM ACCOUNT_MASTER;

SELECT * FROM payee_table;

insert into PAYEE_TABLE values(100,123456,12345,'ABC');

create