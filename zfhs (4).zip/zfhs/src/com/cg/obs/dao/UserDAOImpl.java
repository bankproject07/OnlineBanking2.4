package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.util.DBUtil;

public class UserDAOImpl implements IUserDAO {

	PreparedStatement pst;
	Connection con;
	Statement st;
	@Override
	public Users getUser(int id) throws UserException {
		
		Users user=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM USER_TABLE WHERE USER_ID=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			while(rs.next())
			{
			user=new Users();
		
			user.setUserId(rs.getInt(1));
			user.setAccountId(rs.getLong(2));
			user.setLoginPassword(rs.getString(3));
			user.setSecretQuestion(rs.getString(4));
			user.setSecretAns(rs.getString(5));
			user.setLockStatus(rs.getString(7));
			user.setTransPassword(rs.getString(6));
			}
			
			System.out.println(user);
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting user details"+e.getMessage());
			//e.printStackTrace();
		}
		return user;
	}
	
	@Override
	public void registerUser(Users user) throws UserException {
		
		try{
			con=DBUtil.getConnection();
			String sql="INSERT INTO User_Table VALUES(?,?,?,?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setInt(1, user.getUserId());	
			pst.setLong(2, user.getAccountId());
			pst.setString(3, user.getLoginPassword());
			pst.setString(4, user.getSecretQuestion());
			pst.setString(5, user.getSecretAns());
			pst.setString(6, user.getTransPassword());
			pst.setString(7, "U");
			
		
			pst.execute();
		}
		catch (SQLException e) {
			
			throw new UserException("Problem occured while inserting user details"+e.getMessage());
			//e.printStackTrace();
		}
	
	}
	
	
	
	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		Transactions transaction=null;
		List<Transactions> transactionList=new ArrayList<Transactions>();
		
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Transactions WHERE Account_ID=? and ROWNUM <= 10";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			while(rs.next())
			{
			transaction=new Transactions();
			transaction.setTransaction_ID(rs.getInt(1));
			transaction.setTran_Description(rs.getString(2));
			transaction.setDateOfTransaction(rs.getDate(3));
			transaction.setTransactionType(rs.getString(4).charAt(0));
			transaction.setTransactionAmount(rs.getDouble(5));
			transaction.setAccountID(rs.getLong(6));
			transactionList.add(transaction);
			System.out.println(transactionList);
			}
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting transaction details"+e.getMessage());
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			throw new UserException("Problem occured while getting transaction details"+e.getMessage());
		}
		return transactionList;
	}
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno,Date fromDate,Date toDate) throws UserException {
		
		Transactions transaction=null;
		List<Transactions> transactionList=new ArrayList<Transactions>();
		
		try {
			con=DBUtil.getConnection();
			
			String sql="SELECT * FROM Transactions WHERE Account_ID=? AND DateOfTransaction BETWEEN ? AND ?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			pst.setDate(2, fromDate);
			pst.setDate(3, toDate);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			transaction=new Transactions();
			transaction.setTransaction_ID(rs.getInt(1));
			transaction.setTran_Description(rs.getString(2));
			transaction.setDateOfTransaction(rs.getDate(3));
			transaction.setTransactionType(rs.getString(4).charAt(0));
			transaction.setTransactionAmount(rs.getDouble(5));
			transaction.setAccountID(rs.getLong(6));
			transactionList.add(transaction);
			
			}
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting transaction details"+e.getMessage());
			//e.printStackTrace();
		}
		System.out.println(transactionList);
		return transactionList;
	}
	
	@Override
	public int getCustomerId(Long accountno) throws UserException {

		int customerid=0;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT Customer_ID FROM Account_Master WHERE Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			rs.next();
			customerid=rs.getInt(1);
			
			System.out.println(customerid);
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting CustomerId"+e.getMessage());
			//e.printStackTrace();
		}
		return customerid;

		
	
	}
	@Override
	public Customer getCustomer(int customerid) throws UserException {
		Customer customer=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Customer WHERE Customer_ID=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, customerid);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			rs.next();
			customer=new Customer();	
			customer.setCustomer_ID(rs.getInt(1));
			customer.setCustomer_Name(rs.getString(2));
			customer.setEmail(rs.getString(3));
			customer.setMobileNo(rs.getLong(4));
			customer.setAddress(rs.getString(5));
			customer.setPancard(rs.getString(6));
			
			System.out.println(customer);
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting user details"+e.getMessage());
			//e.printStackTrace();
		}
		return customer;
		}
	
	
	
	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
		
		try {
			con=DBUtil.getConnection();
			String sql="UPDATE Customer SET Mobile_No=? , Address=? WHERE Customer_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, customer.getMobileNo());
			pst.setString(2, customer.getAddress());
			pst.setInt(3, customer.getCustomer_ID());
			pst.execute();	
			System.out.println("updated sucess");
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while update customer contact details");
			//e.printStackTrace();
		}
		
	}
	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		int requestId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_service_num.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			services.setService_ID(id);
			String insertQuery="INSERT INTO Service_Tracker VALUES(?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setLong(1, id);
			pst.setString(2, services.getService_Description());
			pst.setLong(3, services.getAccount_ID());
			pst.setDate(4 , services.getService_Raised_Date());
			pst.setString(5, services.getService_Status());
			pst.executeUpdate();
			requestId=id;
			
		} catch (SQLException e) {
			
			throw new UserException("Problem occured while requesting service");
			//e.printStackTrace();
		}
		return requestId;
	}
	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		
		int transferId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_fundtransfer_id.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			transferInfo.setFundTransfer_Id(id);
			String insertQuery="INSERT INTO Fund_Transfer VALUES(?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setLong(1, id);
			pst.setLong(2, transferInfo.getAccount_Id());
			pst.setLong(3, transferInfo.getPayee_Account());
			pst.setDate(4 ,transferInfo.getDateOfTransfer());
			pst.setDouble(5, transferInfo.getTransferAmount());
			pst.executeUpdate();
			transferId=id;
			
		} catch (SQLException e) {
			
			throw new UserException("Problem occured while performing funds transfer"+e.getMessage());
			//e.printStackTrace();
		}
		return transferId;
	}
	
	@Override
	public void insertTransaction(Transactions transaction)
			throws UserException {
		
		int transactionId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_transactionid.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			transaction.setTransaction_ID(id);
			
		  
			String insertQuery="INSERT INTO Transactions VALUES(?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setInt(1, id);
			pst.setString(2,transaction.getTran_Description());
			pst.setDate(3, transaction.getDateOfTransaction());
			pst.setString(4,String.valueOf(transaction.getTransactionType()));
			pst.setDouble(5, transaction.getTransactionAmount());
			pst.setLong(6, transaction.getAccountID());
			pst.executeUpdate();
		
			
		} catch (SQLException e) {
			
			throw new UserException("Problem occured while performing funds transfer"+e.getMessage());
			//e.printStackTrace();
		}
		
	}

	@Override
	public void updateBalance(double updatedBalance,Long accountId) throws UserException {
		
		try {
			String sql="Update Account_Master set Account_Balance=? where Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setDouble(1, updatedBalance);
			pst.setLong(2, accountId);
			pst.executeQuery();
		} catch (SQLException e) {
			
			throw new UserException("Problem occured while updating balance");

			//e.printStackTrace();
		}
		
	}
	
	
	@Override
	public void changePassword(Users user) throws UserException {
	
		//int userid=user.getUserId();
		try {
			con=DBUtil.getConnection();
			String updateQuery="Update table User_Table set login_password=? where user_id=?";
			pst=con.prepareStatement(updateQuery);
			pst.setString(1, user.getLoginPassword());
			pst.setInt(2, user.getUserId());
			pst.executeUpdate();
		
		}catch (SQLException e) {
			
			throw new UserException("Problem occured while changing password");
			//e.printStackTrace();
		}	

}
	
	@Override
	public void updateLockStatus(int userid) throws UserException {
		
		
		try {
			con=DBUtil.getConnection();
			String updateQuery="Update table User_Table set lock_status=? where user_id=?";
			pst=con.prepareStatement(updateQuery);
			pst.setString(1, "L");
			pst.setInt(2, userid);
			pst.executeUpdate();
		
		}catch (SQLException e) {
			
			throw new UserException("Problem occured while changing password");
			//e.printStackTrace();
		}	
		
	}
	@Override
	public List<Payee> getPayee(long accountid) throws UserException {
		
		
		Payee payee=null;
		List<Payee> payeeList=new ArrayList<Payee>();
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Payee_Table WHERE ACCOUNT_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountid);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			while(rs.next())
				{
					payee=new Payee();
					payee.setPayeeid(rs.getInt(1));
					payee.setPayeeAccountNo(rs.getLong(2));
					payee.setAccountno(rs.getLong(3));
					payee.setNickName(rs.getString(4));
					payeeList.add(payee);
				}
			
			
			System.out.println(payeeList);
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting payee details"+e.getMessage());
			//e.printStackTrace();
		}
		return payeeList;
		
	}
	
	@Override
	public boolean isPayeeAccountExists(long payeeAccountNo)
			throws UserException {
	
		try {
			String sql="select * from Account_Master  where Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, payeeAccountNo);
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
			{
				return true;
			}
			else
			{
			return false;
			}
		} catch (SQLException e) {
			
			throw new UserException("Problem occured while validating payee"+e.getMessage());
			//e.printStackTrace();
		}
	}
	

	@Override
	public void insertPayee(Payee payee) throws UserException {
	
		try{
			con=DBUtil.getConnection();
			String seqsql="SELECT payeeid_seq.nextVal FROM DUAL";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(seqsql);
			if(rs.next())
			payee.setPayeeid(rs.getInt(1));
			String sql="INSERT INTO Payee_Table VALUES(?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setLong(1, payee.getPayeeid());
			pst.setLong(2, payee.getPayeeAccountNo());
			pst.setLong(3, payee.getAccountno());
			pst.setString(4, payee.getNickName());
			
			pst.execute();
		}
		catch (SQLException e) {
			
			throw new UserException("Problem occured while inserting payee details"+e.getMessage());
			//e.printStackTrace();
		}
				
	}

	@Override
	public AccountMaster getAccount(long accountno) {
		
		AccountMaster account=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM ACCOUNT_MASTER WHERE ACCOUNT_ID =?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			rs.next();
			account=new AccountMaster();
			account.setAccountId(rs.getLong(1));
			account.setCustomerId(rs.getInt(2));
			account.setAccountType(rs.getString(3));
			account.setAccountBalance(rs.getDouble(4));
			account.setOpenDate(rs.getDate(5));
			
			System.out.println(account);
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting account details"+e.getMessage());
			//e.printStackTrace();
		}
		return account;
		
		
			}
	

	
}
